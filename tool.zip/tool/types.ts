
export interface ImageVariationResult {
  image: string;
  description: string;
}
